$(document).ready(function(){



    $('#init').click(function(){
        $(this).toggle();
        $('.give_info').css('display','flex');
    
        $('.destroy_info').css('display','flex');
    
        
    });

    $('.give_info').hover(function(){
        $('.give-button').toggle();
    });
    $('.destroy_info').hover(function(){
        $('.destroy-button').toggle();
    });
    
   $('.logo').hover(function(){
       $('.logout').addClass('pink');
    },function(){
        $('.logout').removeClass('pink');
       });
   
   
});

