from django.apps import AppConfig


class GodV2Config(AppConfig):
    name = 'god_v2'
