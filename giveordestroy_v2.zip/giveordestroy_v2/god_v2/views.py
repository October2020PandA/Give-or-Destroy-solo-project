from django.shortcuts import render, redirect, HttpResponse
from django.contrib import messages
from .models import *
import bcrypt
# Create your views here.
def index(request):
    return render(request, 'index.html')

def register(request):
    if request.method == "GET":
        return redirect('/')
    
    
    errors = User.objects.validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
    else:
        pw = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt()).decode()
        
        new_user = User.objects.create(
            user_name = request.POST['user_name'],
            first_name = request.POST['first_name'],
            last_name = request.POST['last_name'],
            email = request.POST['email'],
            password = pw,
            color = request.POST['color'],
            role = request.POST['role'], 
            birthday = request.POST['birthday'],
        )
        addy = Address.objects.create(
            street = request.POST['street'],
            city = request.POST['city'],
            state = request.POST['state'],
            zipcode = request.POST['zipcode'],
            user = new_user,
        )
        print(addy.street)
        print(new_user.has_address.street)


        request.session['user_id'] = new_user.id
        messages.success(request, "You have successfully registered!")
        return redirect('/success')
    return redirect('/')

def login(request):
    if request.method == "GET":
        return redirect('/')
    
    errors = User.objects.log_validator(request.POST)
    if len(errors) > 0 :
        for key, value in errors.items():
            messages.error(request, value)
    else:
        user = User.objects.get(email=request.POST['email'])
        request.session['user_id'] = user.id
        messages.success(request, "You in there!")
        return redirect('/success')
    return redirect('/')

def userdashboard(request):
    if 'user_id' not in request.session:
        return redirect('/')
    user = User.objects.get(id=request.session['user_id'])
    context = {
        'user': user,
        'align': Alignment.objects.all(),
    }
    return render(request, 'user-db.html', context)

def userdark(request):
    if 'user_id' not in request.session:
        return redirect('/')
    user = User.objects.get(id=request.session['user_id'])
    context = {
        'user': user,
        'align': Alignment.objects.all(),
    }
    return render(request, 'user-db-dark.html', context)

def home(request):
    if 'user_id' not in request.session:
        return redirect('/')
    user = User.objects.get(id=request.session['user_id'])
    context = {
        'user': user,
        'align': Alignment.objects.all(),
    }
    return render(request, 'home.html', context)

def settings(request):
    if 'user_id' not in request.session:
        return redirect('/')
    user = User.objects.get(id=request.session['user_id'])
    context = {
        'user': user,
        'align': Alignment.objects.all(),
    }
    return render(request, 'settings.html', context)
def history(request):
    if 'user_id' not in request.session:
        return redirect('/')
    user = User.objects.get(id=request.session['user_id'])
    context = {
        'user': user,
        'align': Alignment.objects.all(),
    }
    return render(request, 'history.html', context)

def add(request):
    if 'user_id' not in request.session:
        return redirect('/')
    user = User.objects.get(id=request.session['user_id'])
    context = {
        'user': user,
        'align': Alignment.objects.all(),
    }
    return render(request, 'add.html', context)

def explore(request):
    if 'user_id' not in request.session:
        return redirect('/')
    user = User.objects.get(id=request.session['user_id'])
    users = User.objects.all()
    context = {
        'user': user,
        'users':users,
        'align': Alignment.objects.all(),
    }
    return render(request, 'explore.html', context)

def friends(request):
    if 'user_id' not in request.session:
        return redirect('/')
    user = User.objects.get(id=request.session['user_id'])
    users = User.objects.all()
    context = {
        'user': user,
        'users':users,
        'align': Alignment.objects.all(),
        'friend':Friend.objects.all(),
    }
    return render(request, 'friends.html', context)

def logout(request):
    request.session.clear()
    return redirect("/")
    
def align_me(request,id):
    
    new_user = User.objects.get(id=id)
    new_user.role = request.POST['role']
    new_user.save()
    return redirect('/settings')

def give(request,id):
    giver = User.objects.get(id=id)
    giving = Alignment.objects.create(
        atype = request.POST['atype'],
        title = request.POST['title'],
        desc = request.POST['desc'],
        image = request.POST['image'],
        location = request.POST['location'],
        user = giver
    )
    return redirect('/explore')

def edit(request,id):
    errors = User.objects.edit_validator_basic(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
    else:
        
        user = User.objects.get(id=id)
        user.user_name = request.POST['user_name']
        user.first_name = request.POST['first_name']
        user.last_name = request.POST['last_name']
        user.role = request.POST['role']
        user.color = request.POST['color']
        user.save()
        messages.success(request, "Account update successful!")
    return redirect('/settings')

def edit_email(request,id):
    errors = User.objects.edit_validator_email(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
    else:
        user = User.objects.get(id=id)
        
        user.email = request.POST['email']
        user.save()
        messages.success(request, "Email update successful!")
    return redirect('/settings')
def edit_pass(request,id):
    errors = User.objects.edit_validator_password(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
    else:
        pw = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt()).decode()
        user = User.objects.get(id=id)
        user.password = pw
        user.save()
        messages.success(request, "Password update successful!")
    return redirect('/settings')

def edit_bday(request,id):
    errors = User.objects.edit_validator_bday(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
    else:
        
        user = User.objects.get(id=id)
        user.birthday = request.POST['birthday']
        user.save()
        messages.success(request, "Birthday update successful!")
    return redirect('/settings')
        

def add_friend(request,id):
    user = User.objects.get(id = request.session['user_id'])
    user_friend = User.objects.get(id=id)
    friend = Friend.objects.create(user=user_friend)
    user.has_friends.add(friend)
    user.save()
    
    return redirect('/friends')