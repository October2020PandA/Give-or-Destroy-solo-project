from __future__ import unicode_literals
from django.db import models
import bcrypt
import re

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
class UserManager(models.Manager):
    def validator(self,postData):
        errors={}
        email_confirm = EMAIL_REGEX
        if len(postData['email'])<1:
            errors['email'] = 'Please enter your email'
        elif not email_confirm.match(postData['email']):
            errors['email'] = 'Email must be valid'
        
        post_email = self.filter(email=postData['email'])
        if len(post_email)>0:
            errors['email'] = "This email already is in use"
        
        post_user = self.filter(user_name=postData['user_name'])
        if len(post_user)>0:
            errors['user_name'] = "This user name is unavailable"
        
        
        if len(postData['user_name']) < 2:
            errors['user_name'] = "User name must be at least 2 characters"
        
        if len(postData['first_name']) < 2:
            errors['first_name'] = "First name must be at least 2 characters"
        
        if len(postData['last_name']) < 2:
            errors['last_name'] = "Last name must be at least 2 characters"
        
        if len(postData['password']) < 8:
            errors['password'] = "Password must be at least 8 characters"
        
        if postData['password'] != postData['con-password']:
            errors['password'] = "These passwords don't match"
        return errors 

    def log_validator(self, postData):
        errors={}
        email_confirm = EMAIL_REGEX
        if len(postData['email'])<1:
            errors['email'] = 'Please enter your email address'
        elif not email_confirm.match(postData['email']):
            errors['email'] = 'Email must be valid'
        if len(postData['password']) < 8:
            errors['password'] = "Password must be at least 8 characters"
        post_email = self.filter(email=postData['email'])
        if len(post_email)== 0:
            errors['email'] = "Email/Password does not match"
        elif not bcrypt.checkpw(postData['password'].encode(), post_email[0].password.encode()):
            errors['email'] = "Email/Password does not match"
        return errors
    
    def edit_validator_basic(self, postData):
        errors={}
        if len(postData['first_name']) < 2:
            errors['first_name'] = "First name must be at least 2 characters"
        if len(postData['last_name']) < 2:
            errors['last_name'] = "Last name must be at least 2 characters"
        user = self.filter(id=int(postData['id']))
        if user[0].user_name != postData['user_name']:
            user_naming = self.filter(user_name=postData['user_name'])
            if len(user_naming)>0:
                errors['user_name'] = "This user name is unavailable"
        return errors

    def edit_validator_email(self, postData):
        errors={}
        email_confirm = EMAIL_REGEX
        if len(postData['email'])<1:
            errors['email'] = 'Please enter your email'
        elif not email_confirm.match(postData['email']):
            errors['email'] = 'Email must be valid'
        user = self.filter(id=int(postData['id']))
        if user[0].email != postData['email']:
            post_email = self.filter(email=postData['email'])
            if len(post_email)>0:
                errors['email'] = "This email already is in use please choose another email address"
        
        return errors
    def edit_validator_password(self, postData):
        errors={}
        if len(postData['password']) < 8:
            errors['password'] = "Password must be at least 8 characters"
        
        if postData['password'] != postData['con-password']:
            errors['password'] = "These passwords don't match"
        return errors

    def edit_validator_bday(self, postData):
        errors={}
        if postData['birthday'] == "yyyy-mm-dd":
            errors['birthday'] = "Please update Birthday"
        return errors

class AddressManager(models.Manager):
    def validator(self,postData):
        errors={}
        if len(postData['street'])<3: 
            errors['street'] = "Please enter street address"
        return errors

class User(models.Model):
    user_name = models.CharField(max_length=255)
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    email = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    color = models.CharField(max_length=255)
    role = models.CharField(max_length=10,null=True)
    birthday = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()

class Friend(models.Model):
    user  = models.ForeignKey(User, related_name="has_friends", blank=True, on_delete=models.CASCADE, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    
class Address(models.Model):
    country = models.CharField(max_length=255, null=True)
    street = models.CharField(max_length=255)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    zipcode = models.IntegerField()
    user = models.OneToOneField(User, related_name="has_address", null=True, on_delete=models.CASCADE)
    objects = AddressManager()

class Alignment(models.Model):
    atype = models.CharField(max_length=10)
    title = models.CharField(max_length=255)
    desc = models.CharField(max_length=255)
    image = models.ImageField(null=True, blank=True, upload_to="images/")
    user = models.ForeignKey(User, related_name="has_alignment", on_delete=models.CASCADE)
    user_likes = models.ManyToManyField(User, related_name='liked')
    location = models.CharField(max_length=255, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class Request(models.Model):
    request_type = models.CharField(max_length=10)
    content = models.CharField(max_length=255)
    alignment = models.ForeignKey(Alignment, related_name="aligned_request", on_delete=models.CASCADE)
    user = models.ForeignKey(User,related_name="has_request", on_delete=models.CASCADE)
    likes = models.ManyToManyField(User, related_name='liked_request')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class Clothing(models.Model):
    details = models.CharField(max_length=255)
    gender = models.CharField(max_length=255)
    size = models.CharField(max_length=255)
    color = models.CharField(max_length=255)
    ctype = models.CharField(max_length=255)
    urlz = models.CharField(max_length=255,null=True)
    alignment = models.ForeignKey(Alignment, related_name="has_clothing", on_delete=models.CASCADE)

class Material(models.Model):
    material = models.CharField(max_length=255)
    percentage = models.IntegerField()
    clothing = models.ManyToManyField(Clothing, related_name="has_materials")

class Comment(models.Model):
    content = models.CharField(max_length=255)
    likes = models.ManyToManyField(User, related_name='like_comment')
    loves = models.ManyToManyField(User, related_name='love_comment')
    laughs = models.ManyToManyField(User, related_name='laugh_comment')
    alignment = models.ForeignKey(Alignment, related_name="has_comment", on_delete=models.CASCADE)
    user = models.ForeignKey(User, related_name="has_comment", on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    

