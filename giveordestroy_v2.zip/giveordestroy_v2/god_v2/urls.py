from django.urls import path
from . import views

urlpatterns=[
    path('', views.index),
    path('login', views.login),
    path('register', views.register),
    path('success', views.userdashboard),
    path('logout', views.logout),
    path('align_me/<int:id>', views.align_me),
    path('give/<int:id>',views.give),
    path('edit-basic/<int:id>', views.edit),
    path('edit-email/<int:id>', views.edit_email),
    path('edit-pass/<int:id>', views.edit_pass),
    path('edit-bday/<int:id>', views.edit_bday),
    path('add-friend/<int:id>', views.add_friend),
    # user dashboard
    path('home', views.home),
    path('settings', views.settings),
    path('add', views.add),
    path('history', views.history),
    path('explore', views.explore),
    path('friends', views.friends),

]