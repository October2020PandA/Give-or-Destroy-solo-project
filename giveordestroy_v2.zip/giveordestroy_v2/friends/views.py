from django.shortcuts import render
from .models import Profile
# Create your views here.
def my_profile(request):
    # profile = Profile.objects.filter(user=request.user)
    # context = {
    #     'profile':profile
    # }
    return render(request, 'friends/index.html')